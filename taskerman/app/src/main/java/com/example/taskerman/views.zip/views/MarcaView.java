package com.example.projetocelularroom.views;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.projetocelularroom.R;
import com.example.projetocelularroom.database.LocalDatabase;
import com.example.projetocelularroom.databinding.ActivityMarcaViewBinding;
import com.example.projetocelularroom.entities.Marca;

public class MarcaView extends AppCompatActivity {
    private LocalDatabase db;
    private ActivityMarcaViewBinding binding;
    private int dbMarcaID;
    private Marca dbMarca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMarcaViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = LocalDatabase.getDatabase(getApplicationContext());
        dbMarcaID = getIntent().getIntExtra(
                "MARCA_SELECIONADA_ID", -1);
    }
    protected void onResume() {
        super.onResume();
        if(dbMarcaID >= 0) {
            getDBMarca();
        } else {
            binding.btnExcluirMarca.setVisibility(View.GONE);
        }
    }
    private void getDBMarca() {
        dbMarca = db.marcaModel().getMarca(dbMarcaID);
        binding.edtMarca.setText(dbMarca.getNome());
    }

    public void salvarMarca(View view) {
        String nomeMarca = binding.edtMarca.getText().toString();
        if (nomeMarca.equals("")) {
            Toast.makeText(this, "Adicione uma marca.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        Marca thisMarca = new Marca(nomeMarca);

        if (dbMarca != null) {
            thisMarca.setMarcaID(dbMarcaID);
            db.marcaModel().update(thisMarca);
            Toast.makeText(this, "Marca atualizada com sucesso.", Toast.LENGTH_SHORT).show();
        } else {
            db.marcaModel().insertAll(thisMarca);
            Toast.makeText(this, "Marca criada com sucesso.", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    public void excluirMarca(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Exclusão de Marca")
                .setMessage("Deseja excluir essa marca?")
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        excluir();
                    }
                })
                .setNegativeButton("Não", null)
                .show();
    }

    private void excluir() {
        try {
            db.marcaModel().delete(dbMarca);
            Toast.makeText(this, "Marca excluída com sucesso", Toast.LENGTH_SHORT).show();
        } catch (SQLiteConstraintException e) {
            Toast.makeText(this, "Impossível excluir marca com celulares cadastrados", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
    public void voltar(View view) {
        finish();
    }
}