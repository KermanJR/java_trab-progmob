package com.example.projetocelularroom.views;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.projetocelularroom.R;
import com.example.projetocelularroom.database.LocalDatabase;
import com.example.projetocelularroom.databinding.ActivityCelularViewBinding;
import com.example.projetocelularroom.entities.Celular;
import com.example.projetocelularroom.entities.Marca;

import java.util.List;

public class CelularView extends AppCompatActivity {

    private ActivityCelularViewBinding binding;
    private LocalDatabase db;
    private int dbCelularID;
    private Celular dbCelular;
    private List<Marca> marcas;
    private Spinner spnMarcas;
    private ArrayAdapter<Marca> marcasAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityCelularViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        db = LocalDatabase.getDatabase(getApplicationContext());

        spnMarcas = binding.spnMarcas;
        dbCelularID = getIntent().getIntExtra(
                "CELULAR_SELECIONADO_ID", -1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(dbCelularID >= 0){
            preencheCelular();
        } else {
            binding.btnExcluirModelo.setVisibility(View.GONE);
        }
        preencheMarcas();
    }

    private void preencheCelular() {
        dbCelular = db.celularModel().getCel(dbCelularID);
        binding.edtModelo.setText(dbCelular.getModelo());
    }

    private void preencheMarcas() {
        marcas = db.marcaModel().getAll();
        marcasAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, marcas);
        spnMarcas.setAdapter(marcasAdapter);
        if(dbCelular != null) {
            spnMarcas.setSelection(dbCelular.getMarcaID() - 1);
        }
    }

    public void salvarCelular(View view) {
        String modelo = binding.edtModelo.getText().toString();
        String novaMarca = "";

        if(spnMarcas.getSelectedItem() != null){
            novaMarca = spnMarcas.getSelectedItem().toString();
        }
        if(modelo.equals("")){
            Toast.makeText(this, "O modelo é obrigatório", Toast.LENGTH_SHORT).show();
            return;
        }
        if(novaMarca.equals("")) {
            Toast.makeText(this, "Entre com uma Marca.", Toast.LENGTH_SHORT).show();
            return;
        }

        Celular novoCelular = new Celular();
        novoCelular.setModelo(modelo);
        novoCelular.setMarcaID(marcas.get(
                spnMarcas.getSelectedItemPosition()).getMarcaID());
        if(dbCelular != null){
            novoCelular.setCelularID(dbCelularID);
            db.celularModel().update(novoCelular);
            Toast.makeText(this, "Celular atualizado com sucesso.",
                    Toast.LENGTH_SHORT).show();
        } else {
            db.celularModel().insertAll(novoCelular);
            Toast.makeText(this, "Celular cadastrado com sucesso.",
                    Toast.LENGTH_SHORT).show();
        }
        finish();
    }
    public void excluirCelular(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Exclusão de Celular")
                .setMessage("Deseja excluir esse celular?")
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        excluir();
                    }
                })
                .setNegativeButton("Não", null)
                .show();
    }

    public void excluir() {
        db.celularModel().delete(dbCelular);
        Toast.makeText(this, "Celular excluído com sucesso.", Toast.LENGTH_SHORT).show();
        finish();
    }
    public void voltar(View view) {
        finish();
    }
}