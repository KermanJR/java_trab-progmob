package com.example.projetocelularroom.views;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.projetocelularroom.database.LocalDatabase;
import com.example.projetocelularroom.databinding.ActivityCelularListBinding;
import com.example.projetocelularroom.entities.CelularMarca;

import java.util.List;

public class CelularList extends AppCompatActivity {
    private ActivityCelularListBinding binding;
    private LocalDatabase db;
    private List<CelularMarca> celMarcas;
    private ListView listViewCelular;
    private Intent edtIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityCelularListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = LocalDatabase.getDatabase(getApplicationContext());
        listViewCelular = binding.listCelular;

        binding.btnHomeCel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        binding.btnAddCel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CelularList.this, CelularView.class));
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        edtIntent = new Intent(this, CelularView.class);
        preencheCelulares();
    }

    private void preencheCelulares() {
        celMarcas = db.celularMarcaModel().getAllCelMarca();
        ArrayAdapter<CelularMarca> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, celMarcas);
        listViewCelular.setAdapter(adapter);

        listViewCelular.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapter, View view,
                                    int position, long id){
                CelularMarca celSelecionado = celMarcas.get(position);
                edtIntent.putExtra("CELULAR_SELECIONADO_ID",
                        celSelecionado.getCelularID());
                startActivity(edtIntent);
            }
        });
    }
}